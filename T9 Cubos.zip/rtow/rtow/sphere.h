#ifndef SPHERE_H
#define SPHERE_H

#include "hittable.h"
#include "vec3.h"
#include "ray.h"
#include "interval.h"
#include "material.h"

class sphere : public hittable {
public:
    point3 min;
    point3 max;
    shared_ptr<material> mat;

    sphere() {}

    sphere(const point3& center, double size, shared_ptr<material> m)
        : mat(m) {
        auto half = size / 2.0;
        min = center - vec3(half, half, half);
        max = center + vec3(half, half, half);
    }

    virtual bool hit(const ray& r, interval ray_t, hit_record& rec) const override {
        for (int a = 0; a < 3; a++) {
            auto invD = 1.0f / r.direction()[a];
            auto t0 = (min[a] - r.origin()[a]) * invD;
            auto t1 = (max[a] - r.origin()[a]) * invD;
            if (invD < 0.0f) std::swap(t0, t1);
            ray_t.min = t0 > ray_t.min ? t0 : ray_t.min;
            ray_t.max = t1 < ray_t.max ? t1 : ray_t.max;
            if (ray_t.max <= ray_t.min)
                return false;
        }

        rec.t = ray_t.min;
        rec.p = r.at(rec.t);
        rec.mat = mat;

        
        vec3 outward_normal;
        point3 hit_point = rec.p;
        const double bias = 0.001;

        if (fabs(hit_point.x() - min.x()) < bias)
            outward_normal = vec3(-1, 0, 0);
        else if (fabs(hit_point.x() - max.x()) < bias)
            outward_normal = vec3(1, 0, 0);
        else if (fabs(hit_point.y() - min.y()) < bias)
            outward_normal = vec3(0, -1, 0);
        else if (fabs(hit_point.y() - max.y()) < bias)
            outward_normal = vec3(0, 1, 0);
        else if (fabs(hit_point.z() - min.z()) < bias)
            outward_normal = vec3(0, 0, -1);
        else
            outward_normal = vec3(0, 0, 1);

        rec.set_face_normal(r, outward_normal);
        return true;
    }
};

#endif 
