from PIL import Image
import sys

def ppm_to_png(ppm_filename, png_filename):
    try:
        with open(ppm_filename, 'r') as file:
        
            format_type = file.readline().strip()
            if format_type != 'P3':
                print('Formato PPM no compatible. Se espera P3.')
                return

            width, height = map(int, file.readline().strip().split())

            max_val = int(file.readline().strip())

            pixels = []
            for line in file:
                values = list(map(int, line.split()))
                pixels.extend(values)

            image = Image.new('RGB', (width, height))
            pixel_data = []
            for i in range(0, len(pixels), 3):
                r, g, b = pixels[i], pixels[i+1], pixels[i+2]
                pixel_data.append((r, g, b))

            image.putdata(pixel_data)
            image.save(png_filename)
            print(f'Imagen convertida exitosamente a {png_filename}')
    except Exception as e:
        print(f'Error al convertir la imagen: {e}')

ppm_to_png('imagen.ppm', 'imagen.png')
